object L10_q2 {
  def countLetterOccurrences(words: List[String]): Int = {
    val letterCounts = words.map(_.length) // Transform words into their lengths
    val totalLetterCount = letterCounts.reduce(_ + _) // Sum up the lengths
    totalLetterCount
  }

  def main(args: Array[String]): Unit = {
    val words = List("apple", "banana", "cherry", "date")
    val totalCount = countLetterOccurrences(words)
    println(s"Total count of letter occurrences: $totalCount")
  }
}

