
object L10_q1 {
  def calculateAverage(temperatures: List[Double]): Double = {
    val fahrenheitTemperatures = temperatures.map(celsius => (celsius * 9/5) + 32)
    val sumOfTemperatures = fahrenheitTemperatures.reduce(_ + _)
    val averageTemperature = sumOfTemperatures / fahrenheitTemperatures.length
    averageTemperature
  }

  def main(args: Array[String]): Unit = {
    val temperatures = List(0, 10.0, 20.0, 30.0)
    val average = calculateAverage(temperatures)
    println(s"Average Fahrenheit temperature: $average")
  }
}
